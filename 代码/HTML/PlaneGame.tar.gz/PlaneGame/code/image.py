def load_image(tkinter):
    return \
        tkinter.PhotoImage(file="../image/background.gif")\
        , tkinter.PhotoImage(file="../image/bee.gif")\
        , tkinter.PhotoImage(file="../image/bullet.gif")\
        , tkinter.PhotoImage(file="../image/hero.gif")\
        , tkinter.PhotoImage(file="../image/hero0.gif")\
        , tkinter.PhotoImage(file="../image/smallplane.gif")
def load_state_image(tkinter):
    return tkinter.PhotoImage(file="../image/start.png")\
        , tkinter.PhotoImage(file="../image/stop.png")
